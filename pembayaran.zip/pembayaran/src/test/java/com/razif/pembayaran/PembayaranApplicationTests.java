package com.razif.pembayaran;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PembayaranApplicationTests {

	@Test
	void contextLoads() {
	}

}
